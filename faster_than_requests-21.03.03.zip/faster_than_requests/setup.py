import setuptools
setuptools.setup(package_data = {"": ["*.nim", "*.nims", "*.cfg", "*.dll", "*.so", "*.h", "*.hpp"]})
